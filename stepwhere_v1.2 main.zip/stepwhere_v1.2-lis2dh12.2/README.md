# Stepwhere firmware v1.2-lis2dh12.2

Main Stepwhere firmware (v1.2: GSM N706B, GPS, battery, server upload) with the
LIS2DS12 code replaced by the LIS2DH12 accelerometer and the software step
counter. **No OTA bootloader**: flash at **0x08000000**.

Source: GitHub `Smartshoe24/Stepwhere-Firmware`, branch `feature/lis2dh12-steps`,
commit `53bb22b`. Board: Stepwhere GSM PCB Rev11, STM32G070CBT6.

## Contents

```
firmware/
  stepwhere_v1.2-lis2dh12.2.bin   raw binary, flash at 0x08000000
  stepwhere_v1.2-lis2dh12.2.hex   Intel HEX (address inside, no address to enter)
  stepwhere_v1.2-lis2dh12.2.elf   with debug symbols (for ST-LINK debugging)
  stepwhere_v1.2-lis2dh12.2.map   linker map (memory use per function)
  size.txt                        flash / RAM use
  SHA256SUMS.txt                  checksums
source/
  stepwhere/stepwhere.ino         main firmware
  stepwhere/accel_steps.cpp/.h    LIS2DH12 + step counter glue (TIM17, every 500 ms)
  libraries/StepwhereMotion/      LIS2DH12 driver, step counter, motion log
  libraries/StepwhereOTA/         W25Q128 flash driver (used by the motion library)
```

Size: 83,404 bytes flash (63 %), 6,248 bytes RAM for variables.

## Flash (Mac)

STM32CubeProgrammer app: connect ST-LINK (SWD), open the `.hex` file, Download.
With the `.bin` file, enter start address `0x08000000`.

Command line:

```sh
/Applications/STMicroelectronics/STM32Cube/STM32CubeProgrammer/STM32CubeProgrammer.app/Contents/MacOs/bin/STM32_Programmer_CLI \
  -c port=SWD -w firmware/stepwhere_v1.2-lis2dh12.2.hex -v -rst
```

## Debug output

USART1 (PB6 TX, PB7 RX), 115200 baud:

```sh
cd ~/stepwhere
python3 ota_uart.py monitor --port /dev/cu.usbserial-0001
```

At start: `[ACCEL] LIS2DH12 found at 0x19, step counter running.`
Every minute: `Steps in last minute`, `Steps total`, `[ACCEL] ...` and `[STEPS] ...`.
Steps appear only while the board is worn in the right shoe and walking;
the first 8 steps of a walk appear together. On a table: 0 (correct).

## Build from source

Arduino IDE or arduino-cli, **STM32duino core 2.12.0** (core 3.x does not build it).
Board "Generic STM32G0 series", part "Generic G070CBTx".
Libraries: TinyGPSPlus 1.0.3, STM32_TimerInterrupt 1.3.0,
STM32duino Low Power 2.0.0, STM32duino RTC 2.0.0, and the two folders in
`source/libraries/` (copy them into `Documents/Arduino/libraries/`).

```sh
arduino-cli compile --fqbn STMicroelectronics:stm32:GenG0:pnum=GENERIC_G070CBTX \
  --libraries source/libraries --output-dir build source/stepwhere
```

This gives a `.bin` identical to the one in `firmware/`.

## Tested on hardware

* Step counter (same code), bring-up firmware, Rev11 board, right shoe,
  31 Oct 2026: walk 100 -> 94, walk 102 -> 98, 3 min foot taps -> 0,
  3 min jiggling -> 0.
* This main firmware, 3 Nov 2026, board on the table for 17 min: sensor OK
  (~24.5 samples/s, 0 errors), 0 steps (correct, not walked).
  Modem answered (IMEI OK); data connection failed (`AT+XIIC=1` ERROR).

## Known open items (to fix in the final-firmware session)

1. No watchdog: a firmware hang is not recovered.
2. `gsm_power_off()` never cuts the modem supply (`ldo_enable(false)` commented out).
3. HTTP: only status 201 counts as success; failed uploads are dropped.
4. Battery protection: no real hysteresis between 3.40 and 3.70 V.
5. `gsm_send_at`: ERROR waits the full timeout; `>` in a reply can give false success; long replies can lose bytes.
6. GPS: stale or 0,0 positions can be sent.
7. Sleep only turns the modem radio off.
8. Compiler warnings: ADC_RESOLUTION redefined, ignored typedef, unused variable, format truncation.
