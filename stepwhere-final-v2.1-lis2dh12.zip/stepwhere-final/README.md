# Stepwhere final firmware v2.1-lis2dh12

Production tracker firmware for the Stepwhere GSM PCB Rev11 (STM32G070CBT6,
Neoway N706, G7A GPS, LIS2DH12). Flash `firmware/stepwhere.ino.bin` at
**0x08000000**, or flash `firmware/stepwhere.ino.hex`.

Built from:

- `stepwhere-stack` `apps/firmware/stepwhere.ino` v2.0: modem start-up and
  recovery, GPS, Wi-Fi scan, serving cell, battery, sleep, HTTP upload.
- `Stepwhere-Firmware` `stepwhere_v1.2 main.zip` (v1.2-lis2dh12.2): the
  LIS2DH12 driver and hardware-tested step counter (`StepwhereMotion`,
  `accel_steps.cpp`).

All LIS2DS12 code and the stack's untuned `pedometer.h` are removed.

## Start-up

1. Rail on (powers the GSM and the GPS together), PWRKEY pulse.
2. LIS2DH12 at 0x19 (SA0/PA1 driven high), 25 Hz FIFO, read every 500 ms from
   TIM17.
3. AT → `ATE0` / `AT+CMEE=2` → `CFUN=1` → SIM READY → GPS UART on → IMEI →
   APN `internet` + `AT+XIIC=1` with a verified IP.
4. Uploads to `http://ingest.stepwhere.in/location` every 8 s.

## Location priority

| Order | Source | Used when | Upload carries |
| --- | --- | --- | --- |
| 1 | GPS | Fix with more than 3 satellites, under 5 s old | GPS lat/long, `gpsFixValid: true` |
| 2 | Wi-Fi | No fix, and the last scan (at most 2 min old) has at least 2 usable APs | `wifi` + `cellular`, `0,0`, `gpsFixValid: false` |
| 3 | GSM | No fix and no usable Wi-Fi | `cellular` only |

The server turns Wi-Fi and cell data into lat/long with Google Geolocation.
Google uses the Wi-Fi APs first and falls back to the cell tower in the same
request. The server needs `CELL_GEOLOCATION_ENABLED=true` and
`GOOGLE_GEOLOCATION_API_KEY`.

The TTL log shows the choice on every upload, for example
`[UPLOAD] source=wifi wifiAps=7 cell=yes steps=120 ...`.

## Build

```sh
./build.sh
```

Needs arduino-cli with **STM32duino core 2.12.0** and **TinyGPSPlus 1.0.3**.
The build uses `--fqbn STMicroelectronics:stm32:GenG0:pnum=GENERIC_G070CBTX`
and `libraries/`. `stepwhere/build_opt.h` sets the 1024-byte UART receive
buffer the sketch requires. For a debug image with AT traffic:
`FIRMWARE_DEFINES="-DSTEPWHERE_LOG_LEVEL=4" ./build.sh`.

Size: 81,944 bytes flash (62 %), 12,152 bytes RAM (32 %).

## Not yet tested on hardware

This image has been compiled, not flashed. Check on a board: the `[ACCEL]`
line and IRQ priority check at boot, `[MODEM] Data connected, IP ...`, the
`[UPLOAD] source=` lines indoors and outdoors, and step counts on a walk.
