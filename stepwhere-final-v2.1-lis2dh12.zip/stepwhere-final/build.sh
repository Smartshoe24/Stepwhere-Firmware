#!/usr/bin/env bash
# Builds the final Stepwhere firmware into ./firmware.
# Needs arduino-cli with STM32duino core 2.12.0 and TinyGPSPlus 1.0.3.
# Set ARDUINO_CLI / ARDUINO_CONFIG to use your own install.
# Extra defines: FIRMWARE_DEFINES="-DSTEPWHERE_LOG_LEVEL=4" ./build.sh
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLI="${ARDUINO_CLI:-${ROOT}/tools/arduino-cli}"
CONFIG_ARGS=()
if [[ -n "${ARDUINO_CONFIG:-}" ]]; then
  CONFIG_ARGS=(--config-file "${ARDUINO_CONFIG}")
elif [[ -f "${ROOT}/tools/arduino-cli.yaml" ]]; then
  CONFIG_ARGS=(--config-file "${ROOT}/tools/arduino-cli.yaml")
fi
OUT="${ROOT}/firmware"

"${CLI}" "${CONFIG_ARGS[@]}" compile \
  --clean \
  --warnings default \
  --fqbn STMicroelectronics:stm32:GenG0:pnum=GENERIC_G070CBTX \
  --libraries "${ROOT}/libraries" \
  --build-path "${ROOT}/.build" \
  --output-dir "${OUT}" \
  --build-property "compiler.cpp.extra_flags=${FIRMWARE_DEFINES:-}" \
  "${ROOT}/stepwhere"

( cd "${OUT}" && sha256sum stepwhere.ino.bin stepwhere.ino.hex > SHA256SUMS.txt )
echo "Firmware: ${OUT}/stepwhere.ino.bin (flash at 0x08000000) and stepwhere.ino.hex"
